# Neurix Release Publishing — Manual Checklist

## Before publishing

- Test the installer, application launch, uninstall process, and preservation of local data.
- Never publish `.env`, secrets, API keys, user SQLite files, or private source code.
- Get explicit approval before making any binary available to the public.
- For Windows distribution, evaluate code signing and Windows Smart App Control compatibility. Never bypass security protection.

## Publish an approved Windows version

1. Use PyInstaller to package the application and Inno Setup to create an installer EXE.
2. Calculate the SHA-256: `Get-FileHash -Algorithm SHA256 .\NeurixAI-Setup.exe`.
3. Calculate file size: `(Get-Item .\NeurixAI-Setup.exe).Length`.
4. Create a GitHub Release (for example, tag `neurix-ai-beta-1.1`) and upload the approved installer.
5. Verify the release asset can be downloaded publicly and matches the expected hash.
6. Update `catalog/versions.json` with the exact release URL, version, channel, platform, filename, hash, size, release date and notes.
7. Verify the catalogue conforms to `catalog/schema.json`.

## Planned Neurix Hub Alpha 0.3 behaviour

- Download catalogue via HTTPS with network timeouts.
- Restrict downloads to approved GitHub release hosts and validate all data.
- Download only on explicit user request to a temporary file.
- Verify size and SHA-256 before moving into the managed cache.
- Ask for permission before launching any installer.
- Preserve local offline library and cached rollback installers.
- Warn that database schema downgrades may not be safe without backups.

The catalogue starts with zero releases, so no public downloads are available yet.
